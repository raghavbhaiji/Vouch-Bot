[![npm](https://img.shields.io/npm/v/anime-actions.svg)](https://www.npmjs.com/package/anime-actions)
[![install size](https://packagephobia.now.sh/badge?p=anime-actions)](https://packagephobia.now.sh/result?p=anime-actions)


[![NPM](https://nodei.co/npm/anime-actions.png?downloads=true&downloadRank=true&stars=true)](https://nodei.co/npm/anime-actions/)




## Installation
```
npm i anime-actions
```
A package for multiple anime actions for discord.

## ACTIONS

| Actions | Description |
| -------- | ----------- |
| `baka` | Gets a URL of a baka image |
| `blush` | Gets a URL of a blush image |
| `cuddle` | Gets a URL of a cuddle image |
| `bite` | Gets a URL of a bite image |
| `dance` | Gets a URL of a dance image |
| `slap`  | Get a URL of a slap image |
| `bonk` | Get a URL of a bonk image |
| `kick` | Get a URL of a kick image |
| `bully` | Get a URL of a bully gif |
| `hug` | Get a URL of a hug image |
| `confused` | Get a URL of a confused image |
| `kiss` | Get a URL of a kiss image |
| `pat` | Get a URL of a pat image |
| `happy`  | Get a URL of a happy image |
| `yes` | Get a URL of a yes image |
| `poke` | Get a URL of a poke image |
| `highfive` | Get a URL of a highfive image |
| `wink` | Get a URL of a wink image |
| `wave` | Get a URL of a wave image |
| `goodnight` | Get a URL of a goodnight image |
| `thinking` | Get a URL of a thinking image |
| `sad` | Get a URL of a sad image |
| `cry` | Get a URL of a cry image |
| `stare` | Get a URL of a stare image |
| `bored` | Get a URL of a cry image |
| `scream` | Get a URL of a cry image |
| `nervous` | Get a URL of a cry image |
| `smile` | Get a URL of a smile image |
| `punch` | Get a URL of a punch image |
| `kill` | Get a URL of a kill image |
| `yeet` | Get a URL of a yeet image |
| `wallpaper` | Get a URL of a wallpaper |
| `zerotwo` | Get a URL of a zerotwo image |

## Examples

Discord.js v13 Example
```js
const { Client, Intents } = require('discord.js');
const anime = require('anime-actions');
const intents = new Intents(32767);

const client = new Client({ intents });

client.once('ready', () => {
	console.log('Ready to hug');
});
client.on('messageCreate', async(message) => {
    if(message.content === 'hug') {
        message.channel.send(await anime.hug())
    }
})
client.login('your-token');
```

Discord.js v12 Example
```js
const { Client} = require('discord.js');
const anime = require('anime-actions');

const client = new Client();

client.once('ready', () => {
	console.log('Ready to hug');
});
client.on('message', async(message) => {
    if(message.content === 'hug') {
        message.channel.send(await anime.hug())
    }
})
client.login('your-token');
```

Await/Async example
```js
const anime = require('anime-actions');

async function kakashi() {
  console.log(await anime.hug());
}

kakashi();
```

## Support Server

<a href="http://bit.ly/botkakashi"><img src="https://discord.c99.nl/widget/theme-2/614018799212953611.png"/></a>

<a href="https://discord.gg/c9Z8Sb2JJz"><img src="https://invidget.switchblade.xyz/c9Z8Sb2JJz"/></a>

## Bots using this api

<a href="https://top.gg/bot/760923630212874251">
    <img src="https://top.gg/api/widget/760923630212874251.svg" alt="Karma Bot" />
</a>

