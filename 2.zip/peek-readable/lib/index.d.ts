export { EndOfStreamError } from './EndOfFileStream.js';
export { StreamReader } from './StreamReader.js';
