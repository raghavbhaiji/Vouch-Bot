# parse-cache-control

Simple function to parse `Cache-Control` headers. Taken from [Wreck](https://github.com/hapijs/wreck).

See `test.js` for usage.
