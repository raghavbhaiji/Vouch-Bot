## 1.2.0

Check for reserved Windows filenames (`CON`, `PRN`, `AUX`, `NUL`,
`COM1`, `LPT1`, etc). See [1].

[1] https://github.com/parshap/node-sanitize-filename/issues/9
