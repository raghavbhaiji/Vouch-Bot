const e = require('./index.js')

console.log(e.INDEX_SIZE_ERR)
