module.exports = require('./lib/getopt.js');
