args = require("../lib").get(
        "inputFilePath outputFilePath");
console.log(JSON.stringify(args, null, "  "));

