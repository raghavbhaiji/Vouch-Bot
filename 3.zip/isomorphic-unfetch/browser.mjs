import fetch from 'unfetch';
export default self.fetch || (self.fetch = fetch);
