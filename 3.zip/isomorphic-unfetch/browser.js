module.exports = self.fetch || (self.fetch = require('unfetch').default || require('unfetch'));
